package com.crud;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    daoContacto dao;
    Adaptador adapter;
    ArrayList<Contacto> lista;
    Contacto c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dao =new daoContacto(MainActivity.this);
        lista = dao.verTodos();
        adapter = new Adaptador(this, lista, dao);
        ListView list = findViewById(R.id.lv_lista);

        //declaracion del boton Añadir
        ImageButton agregar = findViewById(R.id.btnAnadir);

        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //dialog vista prev de registro vista.xml

            }
        });

        agregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Msg de agregar dialogo.xml
                final Dialog dialogo = new Dialog(MainActivity.this);
                dialogo.setTitle("Agregar alumno");
                dialogo.setCancelable(true);
                dialogo.setContentView(R.layout.dialogo);
                dialogo.show();

                //Set edittext + campos
                final EditText matricula = (EditText)dialogo.findViewById(R.id.Etxtmatri);
                final EditText nombre = (EditText)dialogo.findViewById(R.id.Etxtnombre);
                final EditText apellidos = (EditText)dialogo.findViewById(R.id.EtxtApellidos);
                final EditText carrera = (EditText)dialogo.findViewById(R.id.EtxtCarrera);
                final EditText correo = (EditText)dialogo.findViewById(R.id.Etxtcorreo);

                //set buttons agregar y cancelar
                Button agregar=(Button)dialogo.findViewById(R.id.btnAgregar);
                agregar.setText("Guardar");
                Button cancelar=(Button)dialogo.findViewById(R.id.btnCancelar);

                //eventos para boton agregar
                agregar.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            c=new Contacto(
                                    Integer.parseInt(matricula.getText().toString()),
                                    nombre.getText().toString(),
                                    apellidos.getText().toString(),
                                    carrera.getText().toString(),
                                    correo.getText().toString()
                                    );
                            //transferir los elemetos al la objeto dao
                            dao.insertar(c);
                            lista=dao.verTodos();
                            adapter.notifyDataSetChanged();
                            dialogo.dismiss();

                        }catch (Exception e){
                            Toast.makeText(getApplication(), "Error", Toast.LENGTH_SHORT).show();
                        }
                    }
                });


                //eventos boton cancelar
                cancelar.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                               dialogo.dismiss();
                    }
                });
            }
        });

    }
}