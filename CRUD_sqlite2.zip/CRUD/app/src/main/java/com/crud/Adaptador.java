package com.crud;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Adaptador extends BaseAdapter {

    //Lista de elementosa consultar
    ArrayList<Contacto> lista;
    daoContacto dao;
    Contacto c;
    Activity a;


    //Metodos de consulta
    public Adaptador(Activity a, ArrayList<Contacto> lista,  daoContacto dao){
        this.lista = lista;
        this.a =a;
        this.dao = dao;
    }

    //Metodo de lista
    @Override
    public int getCount() {
        return lista.size();
    }

    //metodo de item
    @Override
    public Contacto getItem(int i) {
        c=lista.get(i);
        return null;
    }

    //Metodo de obtencion de item
    @Override
    public long getItemId(int i) {
        c=lista.get(i);
        return c.getid();
    }

    //Metodo constructor CRUD
    @Override
    public View getView(int posicion, View View, ViewGroup viewGroup) {
        View v = View;
        if (v==null){
            LayoutInflater li=(LayoutInflater) a.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v=li.inflate(R.layout.item,null);
        }
        c=lista.get(posicion);

        //Definir obtencion de elementos para item
        TextView matricula = (TextView)v.findViewById(R.id.tvmatri);
        TextView nombre = (TextView)v.findViewById(R.id.tvnombre);
        TextView apellidos = (TextView)v.findViewById(R.id.tvApellidos);
        TextView carrera = (TextView)v.findViewById(R.id.tvCarrera);
        TextView correo = (TextView)v.findViewById(R.id.tvcorreo);

        //Declaracion de botones en item
        ImageButton editar = (ImageButton)v.findViewById(R.id.btnEditar);
        ImageButton eliminar = (ImageButton)v.findViewById(R.id.btnEliminar);

        //set items con obtencion de elemntos desde item
        matricula.setText(""+c.getid());
        nombre.setText(c.getNombre());
        apellidos.setText(c.getApellidos());
        carrera.setText(c.getCarrera());
        correo.setText(c.getCorreo());

        //set operaciones de los botones
        editar.setTag(posicion);
        eliminar.setTag(posicion);

        //Proceso al presionar el btnEditar
        editar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(android.view.View v) {

                int pos = Integer.parseInt(v.getTag().toString());

                //Dialog editar de Dialogo.xml
                final Dialog dialogo = new Dialog(a);
                dialogo.setTitle("Editar Registro");
                dialogo.setCancelable(true);
                dialogo.setContentView(R.layout.dialogo);
                dialogo.show();

                //Set edittext + campos
                final EditText matricula = (EditText)dialogo.findViewById(R.id.Etxtmatri);
                final EditText nombre = (EditText)dialogo.findViewById(R.id.Etxtnombre);
                final EditText apellidos = (EditText)dialogo.findViewById(R.id.EtxtApellidos);
                final EditText carrera = (EditText)dialogo.findViewById(R.id.EtxtCarrera);
                final EditText correo = (EditText)dialogo.findViewById(R.id.Etxtcorreo);

                //set buttons agregar y cancelar
                Button agregar=(Button)dialogo.findViewById(R.id.btnAgregar);
                agregar.setText("Guardar");
                Button cancelar=(Button)dialogo.findViewById(R.id.btnCancelar);

                //Recuperar los datos de registro en BD
                c=lista.get(pos);
                matricula.setText(""+c.getid());
                nombre.setText(c.getNombre());
                apellidos.setText(c.getApellidos());
                carrera.setText(c.getCarrera());
                correo.setText(c.getCorreo());


                //eventos para boton guardar del editar
                agregar.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            c=new Contacto(
                                    Integer.parseInt(matricula.getText().toString()),
                                    nombre.getText().toString(),
                                    apellidos.getText().toString(),
                                    carrera.getText().toString(),
                                    correo.getText().toString()
                            );
                            //transferir los elemetos al la objeto dao
                            dao.editar(c);
                            lista=dao.verTodos();
                            notifyDataSetChanged();
                            dialogo.dismiss();

                        }catch (Exception e){
                            Toast.makeText(a, "Error", Toast.LENGTH_SHORT).show();
                        }
                    }
                });


                //eventos boton cancelar
                cancelar.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialogo.dismiss();
                    }
                });


            }
        });

        //Proceso al precionar el btnEliminar
        eliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(android.view.View v) {
                //Dialog eliminiar confirmacion
                int pos = Integer.parseInt(v.getTag().toString());
                c=lista.get(pos);

                AlertDialog.Builder del = new AlertDialog.Builder(a);
                del.setMessage("¿Está seguro que desea eliminar este elemento?");
                del.setCancelable(false);
                del.setPositiveButton("Si", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        dao.eliminar(c.getid());
                        lista=dao.verTodos();
                        notifyDataSetChanged();

                    }
                });
                del.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                del.show();
            }
        });

        return v;
    }
}
