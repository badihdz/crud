package com.example.crudfirebase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.crudfirebase.models.persona;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {


    //Variables de campos
    EditText nomP, appP, correoP, passwrd;
    //variables de lista
    ListView listaP;
    //variables para rellenar lista
    private List<persona> listperson = new ArrayList<persona>();
    ArrayAdapter<persona> arrayAdapterpersona;

    //variables firebase
FirebaseDatabase firebaseDatabase;
DatabaseReference databaseReference;

    //variable seleccionar persona
    persona personaselect;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Variables de los campos y sus xml
        nomP=findViewById(R.id.txtnombrepersona);
        appP=findViewById(R.id.txtapellidospersona);
        correoP=findViewById(R.id.txtcorreopersona);
        passwrd=findViewById(R.id.txtpasspersona);

        //variable para localizar el listview desde xml
        listaP=findViewById(R.id.list_personas);

        //iniciar metodo de arranque de firebase
        iniciarFirebase();
        
        //iniciar el metodo para colocar elementos en el list view
        listarDatos();

        //capturar el evento de seleccionar una persona de la lista
        listaP.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                personaselect = (persona)parent.getItemAtPosition(position);
                nomP.setText(personaselect.getNombre());
                appP.setText(personaselect.getApellidos());
                correoP.setText(personaselect.getCorreo());
                passwrd.setText(personaselect.getPass());
            }
        });

    }

    //metodo para colocar elementos en el list view
    private void listarDatos() {
        //se localiza el nombre de la tabla/child en firebase
        databaseReference.child("Persona").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //limpar cache al arrancar la app
                listperson.clear();
                //recorrer todos los elementos dentro de Persona en firebase
                for (DataSnapshot objSnapshot : dataSnapshot.getChildren()){
                    //crea el objeto p
                    persona p = objSnapshot.getValue(persona.class);
                    //añade un objeto p a la lista
                    listperson.add(p);
                    //ejecuta un array con cada objeto p y lo almacena en listperson
                    arrayAdapterpersona = new ArrayAdapter<persona>
                            (MainActivity.this, android.R.layout.simple_list_item_1, listperson);
                    //imprime cada campo en un item del list view
                    listaP.setAdapter(arrayAdapterpersona);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) { }
        });
    }

    //Metodo para inicializar firebase
    private void iniciarFirebase() {
        FirebaseApp.initializeApp(this);
        firebaseDatabase =FirebaseDatabase.getInstance();
        //Meotdo simple para aplicar persistencia de datos
        //firebaseDatabase.setPersistenceEnabled(true);
        databaseReference =firebaseDatabase.getReference();

    }

    //metodo para visualizar e integrar el xml menu_main con el main activity
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }


    //metodo para ejecutar un evento al presionar un item dentro de menu_main xml
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        //variables de los campos edittext
        String nombre= nomP.getText().toString();
        String apellidos = appP.getText().toString();
        String correo = correoP.getText().toString();
        String contra = passwrd.getText().toString();

        //seleccion de eventos por medio de switch case
        switch (item.getItemId()) {
            //evento al presionar el boton add
            case R.id.icon_clear:
                Toast.makeText(this, "Campos limpios", Toast.LENGTH_SHORT).show();
                limpiarcajas();
                break;
            case R.id.icon_add:
                //este if verifica que los campos no esten vacios
                if (nombre.equals("")||apellidos.equals("")||correo.equals("")||contra.equals("")){
                    validacion();
                }else{
                    //al no estar vacios los campos almacena el contenido en p
                    persona p = new persona();
                    p.setUid(UUID.randomUUID().toString());
                    p.setNombre(nombre);
                    p.setApellidos(apellidos);
                    p.setCorreo(correo);
                    p.setPass(contra);
                    //inserta el contenido de p en la tabla/child Persona de Firebase
                    databaseReference.child("Persona").child(p.getUid()).setValue(p);
                    //envia un mensaje sobre el evento ocurrido
                    Toast.makeText(this, "Agregado", Toast.LENGTH_SHORT).show();
                    //ejecuta el metodo para limpiar los editText
                    limpiarcajas();
                }break;
                //evento el presionar el boton save
            case R.id.icon_save:
                if (nombre.equals("")||apellidos.equals("")||correo.equals("")||contra.equals("")){
                    validacion();
                }else {
                    persona p = new persona();
                    p.setUid(personaselect.getUid());
                    p.setNombre(nomP.getText().toString().trim());
                    p.setApellidos(appP.getText().toString().trim());
                    p.setCorreo(correoP.getText().toString().trim());
                    p.setPass(passwrd.getText().toString().trim());

                    databaseReference.child("Persona").child(p.getUid()).setValue(p);
                    //envia un mensaje sobre el evento ocurrido
                    Toast.makeText(this, "Guardado", Toast.LENGTH_SHORT).show();
                    limpiarcajas();
                }
                break;

                //evento al presionar el boton delete
            case R.id.icon_delete:
                if (nombre.equals("")||apellidos.equals("")||correo.equals("")||contra.equals("")){
                    validacion();
                }else {
                    persona pe = new persona();
                    pe.setUid(personaselect.getUid());

                    databaseReference.child("Persona").child(pe.getUid()).removeValue();

                    //envia un mensaje sobre el evento ocurrido
                    Toast.makeText(this, "Eliminado", Toast.LENGTH_SHORT).show();
                    limpiarcajas();
                }break;

            default:
                break;
        }
        return true;
    }

    private void limpiarcajas() {
        nomP.setText("");
        appP.setText("");
        correoP.setText("");
        passwrd.setText("");
    }

    private void validacion() {
        String nombre= nomP.getText().toString();
        String apellidos = appP.getText().toString();
        String correo = correoP.getText().toString();
        String contra = passwrd.getText().toString();

        if (nombre.equals("")){
            nomP.setError("Required");
        }else if (apellidos.equals("")){
            appP.setError("Required");
        }else if (correo.equals("")){
            correoP.setError("Required");
        }else if (contra.equals("")){
            passwrd.setError("Required");
        }

    }
}